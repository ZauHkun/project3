<?php $__env->startSection('title','Posts'); ?>

<?php $__env->startSection('content'); ?>
<br>
<style>
.polaroid {
        width: 80%;
        background-color: white;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        margin-bottom: 25px;
        text-align: center;
}

.post-title {
  text-align: center;
  padding: 10px 20px;
}
</style>

<div class="container">
    <div class="col-md-10 offset-md-1"> 
    <?php if(!Auth::check()): ?>
     <div class="card">
         <div class="card-header">
            <h3 style="color:red"><b>Notice! this is a restricted area.</b></h3>
         </div>
         <div class="card-body">
                <h1 style="font-family: 'Times New Roman', Times, serif; text-align:center" >This site is also under construction mode</h1>
                
                <h2 style="color: red;text-align:center">No visitor allowed.</h2>
                
         </div>
     </div>
        
        <?php else: ?>     
                <table class="table table-bordered" id="data_table">
                    <thead>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td>
                                <div class="card">
                                    <div class="card-header">
                                     
                                        <img src="<?php echo e(asset('photo/avatar.jpg')); ?>" style="border-radius:50%; border:solid 1px dark;" width="30px" height="25px" alt="..">                                        
                                        <small><a href="#"><?php echo e($data->user->name); ?> </a></small>                                    
                                    </div>
                                    <div class="card-body">
                                            <?php if(!empty($data->img)): ?>                                                                                            
                                                <div class="polaroid">
                                                    <img src="<?php echo e(asset('uploads/'.$data->img)); ?>" alt="5 Terre" style="width:100%">
                                                    <div class="container">
                                                    <p class="post-title"><?php echo e($data->title); ?></p>
                                                    </div>
                                                </div>                                                  
                                            <?php endif; ?>                                                                                        
                                        
                                        <p class="post-content">                                            
                                            <?php echo e($data->content); ?>

                                        </p>
                                        <small class="float-right">
                                            <?php echo e($data->created_at->diffForHumans()); ?>

                                        </small>
                                    </div>
                                </div>
                            </td>
                           
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table> 
        <?php endif; ?>           
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>