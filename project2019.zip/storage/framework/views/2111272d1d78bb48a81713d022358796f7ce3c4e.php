<?php $__env->startSection('title','register'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-10 offset-md-1">  <br>  <br>  

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <p class="alert alert-danger"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        <div class="card">
            <div class="card-header">
                <h3>Register Here</h3>               
            </div>
            <div class="card-body">
            <form method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group">
                    <label for="name">Name :</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>"  placeholder="Enter a name">              
                </div>
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>"  placeholder="Enter an email">              
                </div>
                <div class="form-group">
                    <label for="password">Password :</label>
                    <input type="password"  class="form-control" name="password" id="password1" placeholder="Password">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password :</label>
                    <input type="password"  class="form-control" name="password_confirmation" id="confirm_password1" placeholder="confirm your password">
                </div>                
                <button type="submit" class="btn btn-primary float-right">register</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>