<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class complain extends Model
{
    //
}
